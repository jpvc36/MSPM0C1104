#!/bin/bash

# Uninstall dependendencies
apt-get remove -y snapclient

echo "Done"
echo "pluginuninstallend"